-- 行程系列相关表结构
-- 在personal_schedule表中添加行程系列相关字段
ALTER TABLE `personal_schedule` 
ADD COLUMN `is_route_series` tinyint DEFAULT '0' COMMENT '是否为行程系列' AFTER `tag`,
ADD COLUMN `route_series_theme` varchar(100) DEFAULT NULL COMMENT '行程系列主题' AFTER `is_route_series`;

-- 行程系列地点表
CREATE TABLE IF NOT EXISTS `route_series_location` (
    `id` bigint NOT NULL AUTO_INCREMENT COMMENT '主键ID',
    `schedule_id` bigint NOT NULL COMMENT '行程ID',
    `name` varchar(200) NOT NULL COMMENT '地点名称',
    `address` varchar(500) DEFAULT NULL COMMENT '地点地址',
    `longitude` decimal(10,7) NOT NULL COMMENT '经度',
    `latitude` decimal(10,7) NOT NULL COMMENT '纬度',
    `sort_order` int DEFAULT '0' COMMENT '排序顺序',
    `create_time` datetime DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
    `update_time` datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
    PRIMARY KEY (`id`),
    KEY `idx_schedule_id` (`schedule_id`),
    KEY `idx_sort_order` (`schedule_id`, `sort_order`),
    CONSTRAINT `fk_route_location_schedule` FOREIGN KEY (`schedule_id`) REFERENCES `personal_schedule` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='行程系列地点表';

-- 行程系列路线结果表
CREATE TABLE IF NOT EXISTS `route_series_route` (
    `id` bigint NOT NULL AUTO_INCREMENT COMMENT '主键ID',
    `schedule_id` bigint NOT NULL COMMENT '行程ID',
    `total_distance` decimal(10,2) DEFAULT NULL COMMENT '总距离（公里）',
    `total_duration` int DEFAULT NULL COMMENT '总时长（分钟）',
    `route_data` json DEFAULT NULL COMMENT '路线详细数据（JSON格式）',
    `create_time` datetime DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
    `update_time` datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
    PRIMARY KEY (`id`),
    UNIQUE KEY `uk_schedule_id` (`schedule_id`),
    CONSTRAINT `fk_route_series_schedule` FOREIGN KEY (`schedule_id`) REFERENCES `personal_schedule` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='行程系列路线结果表';

