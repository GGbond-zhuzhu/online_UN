-- 记账本表
CREATE TABLE IF NOT EXISTS `account_book` (
  `id` BIGINT NOT NULL AUTO_INCREMENT COMMENT '主键ID',
  `user_id` BIGINT NOT NULL COMMENT '用户ID',
  `amount` DECIMAL(10, 2) NOT NULL COMMENT '消费金额',
  `category` VARCHAR(50) NOT NULL COMMENT '消费分类：餐饮、交通、购物、娱乐、学习、其他',
  `description` VARCHAR(500) COMMENT '消费描述',
  `consume_date` DATE NOT NULL COMMENT '消费日期',
  `is_auto_import` TINYINT(1) DEFAULT 0 COMMENT '是否自动导入（来自E卡通）',
  `ecard_record_id` BIGINT COMMENT '关联的E卡通消费记录ID',
  `location` VARCHAR(200) COMMENT '消费地点',
  `pay_method` VARCHAR(50) DEFAULT 'CARD' COMMENT '支付方式：CARD、CASH、ALIPAY、WECHAT、OTHER',
  `create_time` DATETIME DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `update_time` DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
  PRIMARY KEY (`id`),
  INDEX `idx_user_id` (`user_id`),
  INDEX `idx_consume_date` (`consume_date`),
  INDEX `idx_category` (`category`),
  INDEX `idx_ecard_record_id` (`ecard_record_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='记账本表';

-- 饮食记录表
CREATE TABLE IF NOT EXISTS `diet_record` (
  `id` BIGINT NOT NULL AUTO_INCREMENT COMMENT '主键ID',
  `user_id` BIGINT NOT NULL COMMENT '用户ID',
  `diet_date` DATE NOT NULL COMMENT '饮食日期',
  `meal_type` VARCHAR(50) NOT NULL COMMENT '餐次：BREAKFAST、LUNCH、DINNER、SNACK',
  `food_name` VARCHAR(200) NOT NULL COMMENT '食物名称',
  `food_detail` VARCHAR(500) COMMENT '食物详情描述',
  `location` VARCHAR(200) COMMENT '用餐地点',
  `source` VARCHAR(50) NOT NULL COMMENT '来源：CANTEEN、TAKEOUT、RESTAURANT、HOME、OTHER',
  `is_auto_import` TINYINT(1) DEFAULT 0 COMMENT '是否自动导入（来自E卡通食堂消费）',
  `ecard_record_id` BIGINT COMMENT '关联的E卡通消费记录ID',
  `background_color` VARCHAR(20) DEFAULT '#FFB6C1' COMMENT '背景颜色',
  `calories` INT COMMENT '卡路里',
  `price` DECIMAL(10, 2) COMMENT '价格',
  `create_time` DATETIME DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `update_time` DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
  PRIMARY KEY (`id`),
  INDEX `idx_user_id` (`user_id`),
  INDEX `idx_diet_date` (`diet_date`),
  INDEX `idx_meal_type` (`meal_type`),
  INDEX `idx_ecard_record_id` (`ecard_record_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='饮食记录表';

